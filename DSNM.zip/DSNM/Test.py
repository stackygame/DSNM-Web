import tkinter as tk
from tkinter import messagebox
import webbrowser
import ctypes
import os
from uu import decode
from uu import encode
import struct

def custom_print(*args):
    print("".join(map(str, args)))

def custom_input(prompt):
    return input(prompt)

variables = {}

def binary_to_text(binary_code):
    chunks = [binary_code[i:i + 8] for i in range(0, len(binary_code), 8)]
    try:
        return ''.join([chr(int(chunk, 2)) for chunk in chunks])
    except Exception as e:
        return f"Error converting binary: {e}"

def interact_with_c_file(c_file_path):
    if os.path.exists(c_file_path):
        try:
            libc = ctypes.CDLL(c_file_path)
            return "Successfully loaded C file!"
        except Exception as e:
            return f"Error loading C file: {e}"
    else:
        return "C file not found."

def drawing_tool():
    def paint(event):
        x1, y1 = (event.x - 2), (event.y - 2)
        x2, y2 = (event.x + 2), (event.y + 2)
        canvas.create_oval(x1, y1, x2, y2, fill="black", outline="black")

    draw_app = tk.Toplevel()
    draw_app.title("Drawing Tool")
    draw_app.geometry("800x600")

    canvas = tk.Canvas(draw_app, bg="white")
    canvas.pack(fill=tk.BOTH, expand=True)
    canvas.bind("<B1-Motion>", paint)

    tk.Label(draw_app, text="Hold left mouse button to draw").pack()
    tk.Button(draw_app, text="Exit", command=draw_app.destroy).pack()

def calculator():
    def calculate():
        try:
            result = eval(entry.get())
            output_label.config(text=f"Result: {result}")
        except Exception as e:
            output_label.config(text=f"Error: {e}")

    calc_app = tk.Toplevel()
    calc_app.title("Calculator")
    calc_app.geometry("400x300")
    calc_app.configure(bg="lightgray")

    tk.Label(calc_app, text="Enter expression:", bg="lightgray").pack(pady=10)
    entry = tk.Entry(calc_app, width=30)
    entry.pack(pady=5)
    tk.Button(calc_app, text="Calculate", command=calculate).pack(pady=10)
    output_label = tk.Label(calc_app, text="Result: ", bg="lightgray")
    output_label.pack(pady=10)
    tk.Button(calc_app, text="Exit", command=calc_app.destroy).pack(pady=10)

def terminal():
    def execute_command():
        command = command_entry.get()
        output = ""

        if command.startswith("Makefile "):
            filename = command.split(" ")[1]
            try:
                with open(filename, 'w') as f:
                    f.write("New file created in Windows 98 Emulator!")
                output = f"File '{filename}' created successfully."
            except Exception as e:
                output = f"Error: {e}"

        elif command.startswith("Systemdoprint"):
            output = "Windows 98 Emulator: All systems are functional!"

        elif command.startswith("Run Application "):
            app_name = command.split(" ")[2]
            if app_name == "DrawingTool":
                drawing_tool()
                output = "Launched Drawing Tool."
            elif app_name == "Calculator":
                calculator()
                output = "Launched Calculator."
            else:
                output = f"Unknown application: {app_name}"

        else:
            output = "Unknown command."

        output_label.config(text=output)

    term_app = tk.Toplevel()
    term_app.title("Terminal")
    term_app.geometry("600x400")

    tk.Label(term_app, text="Enter Command:").pack(pady=10)
    command_entry = tk.Entry(term_app, width=50)
    command_entry.pack(pady=5)

    execute_button = tk.Button(term_app, text="Execute", command=execute_command)
    execute_button.pack(pady=10)

    output_label = tk.Label(term_app, text="", wraplength=500)
    output_label.pack(pady=20)

    tk.Button(term_app, text="Exit", command=term_app.destroy).pack(pady=10)

def windows98_emulator():
    window = tk.Tk()
    window.title("Windows 98 Emulator")
    window.geometry("800x600")
    window.configure(bg="gray")

    taskbar = tk.Frame(window, bg="darkblue", height=40)
    taskbar.pack(side="bottom", fill="x")

    def start_menu():
        messagebox.showinfo("Start Menu", "Windows 98 Start Menu (Mock)")

    start_button = tk.Button(taskbar, text="Start", bg="lightgray", fg="black", command=start_menu)
    start_button.pack(side="left", padx=10, pady=5)

    desktop = tk.Frame(window, bg="teal")
    desktop.pack(fill="both", expand=True)

    # Add apps to the desktop
    app1_button = tk.Button(desktop, text="App 1: Drawing Tool", bg="lightgray", fg="black", command=drawing_tool)
    app1_button.place(x=50, y=50)

    app2_button = tk.Button(desktop, text="App 2: Calculator", bg="lightgray", fg="black", command=calculator)
    app2_button.place(x=200, y=50)

    terminal_button = tk.Button(desktop, text="App 3: Terminal", bg="lightgray", fg="black", command=terminal)
    terminal_button.place(x=350, y=50)

    window.mainloop()

# Start Windows 98 Emulator
windows98_emulator()
