


print("DSNM.Newcomplier loaded")
import time
import numpy as np

# Simulate the disk-building process with C-style header files
def simulate_printer_with_c_files():
    print("Starting DSNM installer...\n")
    
    # C-style header files (example names)
    files = ["CDS.d", "BISL.d", "DiskBuild.d", "DSNM.py", "dsnmGui.py","Disker.py","VmLog.d","Asmlog.d","Vmfiles.vm","lowlevelDSNm.py","High-lowMangment.//"]
    disk_size = 100  # Total disk size (arbitrary units)
    current_progress = 0  # Initial progress
    file_index = 0  # Start with the first file
    
    while current_progress < disk_size:
        # Generate random progress increment using NumPy
        progress_step = np.random.randint(1, 10)
        current_progress += progress_step

        # Ensure progress doesn't exceed disk size
        current_progress = min(current_progress, disk_size)
        
        # Simulate time delay using the time module
        time.sleep(0.5)
        
        # Display progress
        print(f"Progress: [{'' * current_progress}{'.' * (disk_size - current_progress)}] {current_progress}/{disk_size}")
        
        # Print file being "downloaded"
        if file_index < len(files):
            print(f"Including: {files[file_index]}...")
            file_index += 1

    print("\nDSNM construction complete!")
    print("\nAll DSNM modules like BISL,CDS and DiskBuild included successfully!")

# Run the updated simulation
simulate_printer_with_c_files()
# DSNM is a simple programming language with a syntax similar to Python.
time.sleep(3)
import DSNM