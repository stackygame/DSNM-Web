import tkinter as tk
from tkinter import messagebox
import webbrowser
import ctypes
import os
from uu import decode 
from uu import encode
import struct
def custom_print(*args):
    print("".join(map(str, args)))

def custom_input(prompt):
    return input(prompt)

variables = {}

def binary_to_text(binary_code):
    chunks = [binary_code[i:i + 8] for i in range(0, len(binary_code), 8)]
    try:
        return ''.join([chr(int(chunk, 2)) for chunk in chunks])
    except Exception as e:
        return f"Error converting binary: {e}"

def interact_with_c_file(c_file_path):
    if os.path.exists(c_file_path):
        try:
            libc = ctypes.CDLL(c_file_path)
            return "Successfully loaded C file!"
        except Exception as e:
            return f"Error loading C file: {e}"
    else:
        return "C file not found."

def drawing_tool():
    def paint(event):
        x1, y1 = (event.x - 2), (event.y - 2)
        x2, y2 = (event.x + 2), (event.y + 2)
        canvas.create_oval(x1, y1, x2, y2, fill="black", outline="black")

    draw_app = tk.Toplevel()
    draw_app.title("Drawing Tool")
    draw_app.geometry("800x600")

    canvas = tk.Canvas(draw_app, bg="white")
    canvas.pack(fill=tk.BOTH, expand=True)
    canvas.bind("<B1-Motion>", paint)

    tk.Label(draw_app, text="Hold left mouse button to draw").pack()
    tk.Button(draw_app, text="Exit", command=draw_app.destroy).pack()

def calculator():
    def calculate():
        try:
            result = eval(entry.get())
            output_label.config(text=f"Result: {result}")
        except Exception as e:
            output_label.config(text=f"Error: {e}")

    calc_app = tk.Toplevel()
    calc_app.title("Calculator")
    calc_app.geometry("400x300")
    calc_app.configure(bg="lightgray")

    tk.Label(calc_app, text="Enter expression:", bg="lightgray").pack(pady=10)
    entry = tk.Entry(calc_app, width=30)
    entry.pack(pady=5)
    tk.Button(calc_app, text="Calculate", command=calculate).pack(pady=10)
    output_label = tk.Label(calc_app, text="Result: ", bg="lightgray")
    output_label.pack(pady=10)
    tk.Button(calc_app, text="Exit", command=calc_app.destroy).pack(pady=10)

def disk_build():
    custom_print("DSNM Disk Builder Simulator")
    custom_print("Done!")
    import Disker

def cds_module():
    custom_print("CDS Is A module for DSNM With Only 4 Functions")
    i = custom_input("Pls Enter this command (Breakterminal,GetV,PrintObj,Func): ")

    def quit_terminal():
        custom_print("Say /exit")

    def version(version):
        custom_print(f"ConsoleDOS Module {version}")

    def console_print(*args):
        custom_print("".join(map(str, args)))

    if i.startswith("PrintObj "):
        console_print(i[9:])
    elif i.startswith("Func "):
        console_print(i[5:])
        block = custom_input("Enter block: ")
        if block.startswith("PrintObj"):
            console_print(block[9:])
        elif block == "GetV":
            version("V1.0")
        else:
            console_print("Unexecutable Command")
    elif i == "GetV":
        version("V1.0")
    elif i == "Breakterminal":
        quit_terminal()
    else:
        custom_print("Ouch that hurt My Disk 🤕🤕🤕😭😭😭🥺🥺🥺🥺🥺😟😟😟")

def windows98_emulator():
    window = tk.Tk()
    window.title("Windows 98 Emulator")
    window.geometry("800x600")
    window.configure(bg="gray")

    taskbar = tk.Frame(window, bg="darkblue", height=40)
    taskbar.pack(side="bottom", fill="x")

    def start_menu():
        messagebox.showinfo("Start Menu", "Windows 98 Start Menu (Mock)")

    start_button = tk.Button(taskbar, text="Start", bg="lightgray", fg="black", command=start_menu)
    start_button.pack(side="left", padx=10, pady=5)

    desktop = tk.Frame(window, bg="teal")
    desktop.pack(fill="both", expand=True)

    app1_button = tk.Button(desktop, text="App 1: Drawing Tool", bg="lightgray", fg="black", command=drawing_tool)
    app1_button.place(x=50, y=50)

    app2_button = tk.Button(desktop, text="App 2: Calculator", bg="lightgray", fg="black", command=calculator)
    app2_button.place(x=200, y=50)

    window.mainloop()

custom_print("DSNM language V1.3\n")
custom_print("Available Commands:")
custom_print("  /print [text]       : Print text or use var:variable to print a variable's value")
custom_print("  /set [var] [value]  : Set a variable")
custom_print("  /get [var]          : Get a variable's value")
custom_print("  /add                : Adds two numbers")
custom_print("  /subtract           : Subtracts two numbers")
custom_print("  /multiply           : Multiplies two numbers")
custom_print("  /divide             : Divides two numbers")
custom_print("  /import Bin         : Convert binary code to text")
custom_print("  /import Asmlog      : Interact with a C file (simulate loading a shared library)")
custom_print("  /import DiskBuild   : Simulates DSNM Disk Builder functionality")
custom_print("  /import CDS         : Launch CDS module with multiple features")
custom_print("  /web_open           : Open a URL in the default web browser")
custom_print("  /VmLog              : Launch Windows 98 emulator with apps")
custom_print("  /exit               : Exit the console\n")

while True:
    command = custom_input("Enter command: ")

    if command.startswith("/print "):
        to_print = command[7:]
        if to_print.startswith("var:"):
            var_name = to_print[4:]
            custom_print(variables.get(var_name, f"Variable {var_name} not found"))
        else:
            custom_print(to_print)

    elif command.startswith("/set "):
        parts = command.split()
        if len(parts) == 3:
            variables[parts[1]] = parts[2]
            custom_print(f"Variable {parts[1]} set to {parts[2]}")
        else:
            custom_print("Usage: /set variable value")
    
    elif command.startswith("/get "):
        var_name = command[5:]
        custom_print(variables.get(var_name, f"Variable {var_name} not found"))
    
    elif command == "/add":
        try:
            num1 = float(custom_input("Enter first number: "))
            num2 = float(custom_input("Enter second number: "))
            custom_print(f"Result: {num1 + num2}")
        except Exception as e:
            custom_print(f"Error: {e}")
    
    elif command == "/subtract":
        try:
            num1 = float(custom_input("Enter first number: "))
            num2 = float(custom_input("Enter second number: "))
            custom_print(f"Result: {num1 - num2}")
        except Exception as e:
            custom_print(f"Error: {e}")
    
    elif command == "/multiply":
        try:
            num1 = float(custom_input("Enter first number: "))
            num2 = float(custom_input("Enter second number: "))
            custom_print(f"Result: {num1 * num2}")
        except Exception as e:
            custom_print(f"Error: {e}")
    
    elif command == "/divide":
        try:
            num1 = float(custom_input("Enter first number: "))
            num2 = float(custom_input("Enter second number: "))
            if num2 != 0:
                custom_print(f"Result: {num1 / num2}")
            else:
                custom_print("Error: Division by zero is not allowed.")
        except Exception as e:
            custom_print(f"Error: {e}")
    
    elif command.startswith("/import Bin"):
        binary_code = custom_input("Enter binary code to convert to text: ")
        result = binary_to_text(binary_code)
        custom_print(f"Text: {result}")
    
    elif command.startswith("/import Asmlog"):
        c_file_path = custom_input("Enter C file path: ")
        result = interact_with_c_file(c_file_path)
        custom_print(result)
    
    elif command == "/import DiskBuild":
        disk_build()
    
    elif command == "/import CDS":
        cds_module()
    
    elif command == "/web_open":
        url = custom_input("Enter URL: ")
        try:
            webbrowser.open(url)
            custom_print("Opened URL in default web browser.")
        except Exception as e:
            custom_print(f"Error opening URL: {e}")
    
    elif command == "/VmLog":
        custom_print("Launching Windows 98 Emulator...")
        windows98_emulator()
    
    elif command == "/exit":
        custom_print("Exiting program.")
        break
    elif command.startswith("/packbin "):
        binary_code = command[10:]
        packed_data = struct.pack(f'{len(binary_code)}s', binary_code.encode())
        custom_print(f"Packed data: {packed_data}")
    elif command.startswith("/unpackbin "):
        packed_data = command[11:]
        unpacked_data = struct.unpack(f'{len(packed_data)}s', packed_data.encode())
        custom_print(f"Unpacked data: {unpacked_data}")
    elif command.startswith("/decode "):
        decode.decode(command[8:], 'DSNMinst')
        custom_print("Decoded file saved as 'DSNMinst'")
    elif command.startswith("/encode "):
        encode.encode(command[8:], 'DSNMinst')
        custom_print("Encoded file saved as 'DSNMinst'")
    else:
        custom_print("Unknown command")
