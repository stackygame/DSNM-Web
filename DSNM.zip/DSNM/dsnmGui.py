import tkinter as tk
from tkinter import messagebox

class DSNMApp:
     
    def __init__(self, root):
        self.root = root
        self.root.title("DSNM Custom Program")
        self.variables = {}
        self.create_widgets()

    def create_widgets(self):
        # GUI layout
        self.command_label = tk.Label(self.root, text="Enter Command:")
        self.command_label.pack()

        self.command_entry = tk.Entry(self.root, width=50)
        self.command_entry.pack()

        self.run_button = tk.Button(self.root, text="Run Command", command=self.process_command)
        self.run_button.pack()

        self.output_area = tk.Text(self.root, height=15, width=60)
        self.output_area.pack()

        self.exit_button = tk.Button(self.root, text="Exit Program", command=self.root.quit)
        self.exit_button.pack()

    def save_to_dsnm(self, file_name, data):
        try:
            with open(file_name + ".dsnm", "w") as file:
                file.write(data)
            self.output_area.insert(tk.END, f"Data saved to {file_name}.dsnm\n")
        except Exception as e:
            self.output_area.insert(tk.END, f"Error saving to file: {e}\n")

    def load_from_dsnm(self, file_name):
        try:
            with open(file_name + ".dsnm", "r") as file:
                data = file.read()
            self.output_area.insert(tk.END, f"Data loaded from {file_name}.dsnm:\n{data}\n")
        except FileNotFoundError:
            self.output_area.insert(tk.END, f"Error: {file_name}.dsnm not found\n")
        except Exception as e:
            self.output_area.insert(tk.END, f"Error loading file: {e}\n")

    def process_command(self):
        command = self.command_entry.get()
        self.command_entry.delete(0, tk.END)  # Clear the entry field

        if command.startswith("/print "):
            self.output_area.insert(tk.END, command[7:] + "\n")
        elif command.startswith("/set "):
            parts = command.split(maxsplit=2)
            if len(parts) == 3:
                self.variables[parts[1]] = parts[2]
                self.output_area.insert(tk.END, f"Variable {parts[1]} set to {parts[2]}\n")
            else:
                self.output_area.insert(tk.END, "Usage: /set variable value\n")
        elif command.startswith("/get "):
            var_name = command.split()[1]
            if var_name in self.variables:
                self.output_area.insert(tk.END, f"{self.variables[var_name]}\n")
            else:
                self.output_area.insert(tk.END, f"Variable {var_name} not found\n")
        elif command.startswith("/save "):
            parts = command.split(maxsplit=2)
            if len(parts) == 3:
                self.save_to_dsnm(parts[1], parts[2])
            else:
                self.output_area.insert(tk.END, "Usage: /save filename data\n")
        elif command.startswith("/load "):
            parts = command.split(maxsplit=1)
            if len(parts) == 2:
                self.load_from_dsnm(parts[1])
            else:
                self.output_area.insert(tk.END, "Usage: /load filename\n")
       
        elif command.startswith("/exit"):
            self.root.quit()
        else:
            self.output_area.insert(tk.END, "Unknown command. Please check syntax.\n")
     
    

# Initialize and run the Tkinter application
if __name__ == "__main__":
    root = tk.Tk()
    app = DSNMApp(root)
    root.mainloop()
