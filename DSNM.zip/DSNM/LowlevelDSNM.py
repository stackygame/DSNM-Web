import struct
import webbrowser

def custom_print(*args):
    print("".join(map(str, args)))

def custom_input(prompt):
    return input(prompt)

variables = {}
print("l.co trademark of l.co creative science")
while True:
    syantx = input("Enter command: ")

    if syantx.startswith("/print "):
        custom_print(syantx[7:])
    elif syantx.startswith("/set "):
        parts = syantx.split()
        if len(parts) == 3:
            variables[parts[1]] = parts[2]
            custom_print(f"Variable {parts[1]} set to {parts[2]}")
        else:
            custom_print("Usage: /set variable value")
    elif syantx.startswith("/get "):
        # Extract the variable name inside quotes
        if "\"" in syantx:
            var_name = syantx.split("\"")[1]  # Get the text inside quotes
            if var_name in variables:
                custom_print(f"Value of '{var_name}': {variables[var_name]}")
            else:
                custom_print(f"Variable '{var_name}' not found")
        else:
            custom_print("Usage: /get \"variable_name\"")
    elif syantx == "/add":
        num1 = float(custom_input("Enter first number: "))
        num2 = float(custom_input("Enter second number: "))
        custom_print(f"Result: {num1 + num2}")
    elif syantx == "/subtract":
        num1 = float(custom_input("Enter first number: "))
        num2 = float(custom_input("Enter second number: "))
        custom_print(f"Result: {num1 - num2}")
    elif syantx == "/multiply":
        num1 = float(custom_input("Enter first number: "))
        num2 = float(custom_input("Enter second number: "))
        custom_print(f"Result: {num1 * num2}")
    elif syantx == "/divide":
        num1 = float(custom_input("Enter first number: "))
        num2 = float(custom_input("Enter second number: "))
        if num2 != 0:
            custom_print(f"Result: {num1 / num2}")
        else:
            custom_print("Error: Division by zero is not allowed.")
    elif syantx.startswith("/pack "):
        var_name = syantx.split()[1]
        if var_name in variables:
            try:
                packed_data = struct.pack('10s', variables[var_name].encode())
                variables[var_name] = packed_data  # Store the packed binary
                custom_print(f"Variable '{var_name}' packed as binary data.")
            except struct.error:
                custom_print("Error packing data.")
        else:
            custom_print(f"Variable '{var_name}' not found")
    elif syantx.startswith("/unpack "):
        var_name = syantx.split()[1]
        if var_name in variables:
            try:
                unpacked_data = struct.unpack('10s', variables[var_name])[0].decode().strip('\x00')
                custom_print(f"Variable '{var_name}' unpacked: {unpacked_data}")
            except struct.error:
                custom_print("Error unpacking data.")
        else:
            custom_print(f"Variable '{var_name}' not found")
    elif syantx == "/exit":
        custom_print("Exiting program.")
        break
    else:
        custom_print("Unknown command")
